def receive():
    return "这是来自 100XX 的短信"
