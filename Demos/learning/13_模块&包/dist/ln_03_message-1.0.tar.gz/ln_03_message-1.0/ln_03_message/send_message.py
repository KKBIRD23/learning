def send(text):
    print(f'正在发送...{text}')
